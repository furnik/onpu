import React from 'react';
import {Add} from '../../components/Add';

export const AddContainer: React.FC = () => {
	return <Add />;
};
