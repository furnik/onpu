import React from 'react';
import {About} from '../../components/About';

export const AboutContainer: React.FC = () => {
	return <About />;
};
