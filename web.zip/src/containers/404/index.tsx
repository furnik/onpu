import React from 'react';
import {Error404} from '../../components/404';

export const Error404Container: React.FC = () => {
	return <Error404 />;
};
