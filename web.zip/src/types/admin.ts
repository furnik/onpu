export enum Tabs {
  types = 'admin:types',
  tags = 'admin:tags',
  speciality = 'admin:specialities',
  projects = 'admin:projects',
}
