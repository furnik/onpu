export type CommonT = {
  id: string;
  en: string;
  ua: string;
}

export type CommonValueT = {
  en: string;
  ua: string;
}
