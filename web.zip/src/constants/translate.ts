export enum Languages {
  ua = 'ua',
  en = 'en'
}
