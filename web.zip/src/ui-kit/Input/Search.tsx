import React, {ChangeEvent, useState} from 'react';
import {SearchStyledInput, SearchLabel, CloseBtnWrapper} from './styles';
import {CloseBtn} from '../Button/Close';

interface Props {
  placeholder: string;
  onChange: (value: string) => void;
}

export const SearchInput: React.FC<Props> = ({placeholder, onChange}) => {
	const [value, setValue] = useState('');
	const onCloseHandler = () => {
		setValue('');
	};
	const changeValueHandler = (event: ChangeEvent<HTMLInputElement>) => {
		setValue(event.target.value);
		onChange(event.target.value);
	};
	return (
		<SearchLabel>
			<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
				<path d="M17.5 17.5L13.875 13.875M15.8333 9.16667C15.8333 12.8486 12.8486 15.8333 9.16667 15.8333C5.48477 15.8333 2.5 12.8486 2.5 9.16667C2.5 5.48477 5.48477 2.5 9.16667 2.5C12.8486 2.5 15.8333 5.48477 15.8333 9.16667Z" stroke="#667085" strokeWidth="1.66667" strokeLinecap="round" strokeLinejoin="round"/>
			</svg>
			<SearchStyledInput value={value} onChange={changeValueHandler} type="text" placeholder={placeholder} />
			<CloseBtnWrapper>
				<CloseBtn onClick={onCloseHandler} />
			</CloseBtnWrapper>
		</SearchLabel>
	);
};
